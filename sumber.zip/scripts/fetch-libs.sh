#!/usr/bin/env bash
# Mengunduh pustaka PDF & font ke www/lib supaya aplikasi bisa berjalan offline
set -e
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
( cd "$TMP" && npm init -y >/dev/null && npm install --no-audit --no-fund jspdf@2.5.1 pdfjs-dist@3.11.174 @fontsource/inter@5 >/dev/null )
mkdir -p www/lib/inter/files
cp "$TMP/node_modules/jspdf/dist/jspdf.umd.min.js" www/lib/
cp "$TMP/node_modules/pdfjs-dist/build/pdf.min.js" www/lib/
cp "$TMP/node_modules/pdfjs-dist/build/pdf.worker.min.js" www/lib/
: > www/lib/inter/inter.css
for w in 400 500 600 700; do
  cat "$TMP/node_modules/@fontsource/inter/latin-$w.css" >> www/lib/inter/inter.css
done
cp "$TMP/node_modules/@fontsource/inter/files/"inter-latin-*-normal.woff2 www/lib/inter/files/ 2>/dev/null || true
cp "$TMP/node_modules/@fontsource/inter/files/"inter-latin-*-normal.woff www/lib/inter/files/ 2>/dev/null || true
ls -la www/lib
