/* ASA-Arsite3D — jembatan aplikasi mandiri (Android / Windows / web) */
(function(){
  var MIME={png:'image/png',pdf:'application/pdf',svg:'image/svg+xml',zip:'application/zip',json:'application/json',csv:'text/csv',dxf:'application/dxf',txt:'text/plain'};
  function mime(n){var e=(n.split('.').pop()||'').toLowerCase();return MIME[e]||'application/octet-stream'}
  function b64(blob){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(String(r.result).split(',')[1]||'')};r.onerror=rej;r.readAsDataURL(blob)})}
  window.ASA_NATIVE_DL={save:async function(o){
    var name=o.filename,data=o.data;
    var blob=data instanceof Blob?data:new Blob([data],{type:mime(name)+';charset=utf-8'});
    if(window.AndroidBridge&&window.AndroidBridge.saveFile){
      var ok=window.AndroidBridge.saveFile(name,await b64(blob),blob.type||mime(name));
      if(!ok)throw new Error('Gagal menyimpan file');return;
    }
    var u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();
    setTimeout(function(){URL.revokeObjectURL(u)},5000);
  }};
  if('serviceWorker' in navigator&&location.protocol==='https:'&&!window.AndroidBridge&&location.hostname!=='appassets.androidplatform.net'){
    window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})});
  }
})();
