# ASA-Arsite3D — sumber aplikasi Android & Windows
© PT. ASA Rental

Folder ini berisi aplikasi ASA-Arsite3D versi mandiri (tidak butuh Claude), plus
"pabrik" otomatis di GitHub yang membuat **APK Android** dan **installer Windows (.exe)**.

## Cara mendapatkan APK & EXE (tanpa memasang software apa pun)
1. Buat akun gratis di https://github.com lalu klik **New repository**.
   - Nama: `asa-arsite3d`
   - Pilih **Private** (WAJIB — folder ini berisi kunci tanda tangan APK Anda).
   - Klik **Create repository**.
2. Di halaman repository, klik **uploading an existing file**.
   Tarik SEMUA isi folder ini (termasuk folder `.github`) ke halaman itu, lalu klik **Commit changes**.
   > Folder `.github` tersembunyi di Windows/Mac. Aktifkan "tampilkan file tersembunyi",
   > atau upload lewat aplikasi GitHub Desktop.
3. Buka tab **Actions**. Proses "Build ASA-Arsite3D" berjalan otomatis (± 5–10 menit).
4. Setelah centang hijau, klik proses tersebut → bagian **Artifacts** di bawah:
   - **ASA-Arsite3D-Android** (zip) → berisi `ASA-Arsite3D.apk` (pasang di HP) dan `.aab` (untuk Google Play)
   - **ASA-Arsite3D-Windows** (zip) → berisi `ASA-Arsite3D-Setup-x.exe` (installer) dan `ASA-Arsite3D-Portable-x.exe` (langsung jalan)

Setiap kali Anda mengunggah versi baru `www/index.html`, APK & EXE dibuat ulang otomatis
dan bisa dipasang menimpa versi lama (data proyek tetap ada).

## Memasang
- **Android:** kirim `ASA-Arsite3D.apk` ke HP → buka → izinkan "Instal aplikasi tidak dikenal" → Instal.
  Hasil ekspor (PDF/PNG/DXF/RAB) tersimpan di folder **Download/ASA-Arsite3D**.
- **Windows:** jalankan `ASA-Arsite3D-Setup-x.exe`. Jika muncul "Windows protected your PC",
  klik **More info → Run anyway** (muncul karena installer belum memakai sertifikat berbayar).

## PENTING — simpan baik-baik
`android/asa-arsite3d.jks` + `android/keystore.properties` adalah kunci tanda tangan APK.
Simpan cadangannya. Tanpa file ini, versi berikutnya tidak bisa dipasang menimpa versi lama,
dan aplikasi tidak bisa diperbarui di Google Play.

## Isi folder
- `www/` — aplikasi (index.html, logo, ikon, manifest)
- `android/` — proyek Android (WebView, offline, simpan file ke Download)
- `windows/` — proyek Windows (Electron, installer NSIS + portable)
- `scripts/fetch-libs.sh` — mengunduh pustaka PDF & font Inter agar bisa offline
- `.github/workflows/build.yml` — pembuat APK & EXE otomatis

## Catatan
- Data proyek tersimpan di perangkat masing-masing. Pindahkan antarperangkat lewat Ekspor/Impor JSON.
- Sinkronisasi cloud hanya tersedia saat aplikasi dibuka di claude.ai.
